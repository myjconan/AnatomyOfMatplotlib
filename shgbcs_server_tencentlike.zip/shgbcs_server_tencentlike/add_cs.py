import shgbDB_sqlalchemy as db

if __name__ == '__main__':
    db.add_cs(csid='cs01',csname='ma',cspassword=1)
    db.add_cs(csid='cs02', csname='yang', cspassword=1)
    db.add_cs(csid='cs03', csname='jiang', cspassword=1)
    db.add_cs(csid='cs04', csname='chen', cspassword=1)
