# -*- coding: UTF-8 -*-
import os, json
import datetime
import time
from sqlalchemy.orm import sessionmaker
import pandas as pd
# 创建数据库连接
import pymysql

pymysql.install_as_MySQLdb()
from sqlalchemy.engine import create_engine

conn_url = 'mysql://root:123456@localhost:3306/shgb_csdb?charset=utf8'
engine = create_engine(conn_url, echo=False)
# 创建ORM基类
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base(bind=engine)
# 引入列和字段类型
from sqlalchemy import Column
from sqlalchemy.types import Integer, String, Date, DateTime, Float, Text, VARCHAR


# 创建自定义ORM类
class CS(Base):
    __tablename__ = 'cs'
    csid = Column(VARCHAR(50), primary_key=True)
    csname = Column(VARCHAR(50))
    cspassword = Column(VARCHAR(50))
    csphonenumber = Column(VARCHAR(50))

    def __repr__(self):
        # return u'<csname:%s,cspassword:%s>' % (self.csname, self.cspassword)
        return [self.csid, self.csname]


class User(Base):
    __tablename__ = 'user'
    userid = Column(VARCHAR(50), primary_key=True)
    telephonenumber = Column(VARCHAR(50))


class Chat_history(Base):
    __tablename__ = 'chat_history'
    index = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(VARCHAR(50))
    userid = Column(VARCHAR(50))
    csid = Column(VARCHAR(50))
    funcname = Column(VARCHAR(50))
    funcvalue = Column(VARCHAR(1000))


class Csr_local(Base):
    __tablename__ = 'csr_local'
    index = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(VARCHAR(50))
    userid = Column(VARCHAR(50))
    csid = Column(VARCHAR(50))
    funcname = Column(VARCHAR(50))
    funcvalue = Column(VARCHAR(1000))


class Feedback(Base):
    __tablename__ = 'feedback'
    index = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(VARCHAR(50))
    username = Column(VARCHAR(50))
    usertel = Column(VARCHAR(50))
    userdepartment = Column(VARCHAR(50))
    usermsg = Column(VARCHAR(1000))


Base.metadata.create_all()


def replace_sp_char(str):
    str_list = []
    for index in range(len(str)):
        s = str[index].replace(' ', '').replace('\n', '').replace('\r', '')
        str_list.append(s)
    str_new = ''.join(str_list)
    return str_new


# 方法
def query_logincs(csname, cspassword):
    # print('csname:%s,cspassword:%s' % (csname, cspassword))
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    cs = conn.query(CS.csid, CS.csname).filter(CS.csname == csname, CS.cspassword == cspassword).one_or_none()
    return cs


def query_cs(csid):
    # print('csid:%s' % (csid))
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    cs = conn.query(CS.csid, CS.csname).filter(CS.csid == csid).one_or_none()
    return cs


def add_chat_history(funcvalue, timestamp=None, userid=None, csid=None, funcname=None):
    if timestamp is None:
        timestamp = int(round(time.time() * 1000))
    if userid is None:
        userid = "defalut"
    if csid is None:
        csid = "服务器"
    if funcname is None:
        funcname = "系统提醒"
    funcvalue = replace_sp_char(funcvalue)
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    try:
        chat_his = Chat_history(timestamp=timestamp, userid=userid, csid=csid, funcname=funcname, funcvalue=funcvalue)
        conn.add(chat_his)
        conn.commit()
        conn.refresh(chat_his)
    except:
        pass
    conn.close()
    return timestamp


def add_csr_local(chat_history, csid=None):
    for key in chat_history.keys():
        chat_history[key] = replace_sp_char(chat_history[key])
    if csid is None:
        csid = 'csr'
    userid = chat_history['userid']
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    # print(chat_history)
    try:
        for chat in chat_history:
            pos_funcname = chat.find('func_name')
            pos_funcvalue = chat.find('value')
            if pos_funcname > -1:
                timestamp = chat[:pos_funcname]
                funcname = chat_history[chat]
                chat_his = Csr_local(timestamp=timestamp, userid=userid, csid=csid, funcname=funcname)
                conn.add(chat_his)
                conn.commit()
                conn.refresh(chat_his)
            elif pos_funcvalue > -1:
                timestamp = chat[:pos_funcvalue]
                funcvalue = chat_history[chat]
                conn.query(Csr_local).filter(Csr_local.timestamp == timestamp, Csr_local.userid == userid).update(
                    {"funcvalue": funcvalue})
                conn.commit()
            else:
                pass
    except:
        pass
    conn.close()
    return chat_history


def add_feedback(username, usertel, userdepartment, usermsg, timestamp=None):
    if timestamp is None:
        timestamp = int(round(time.time() * 1000))
    usermsg = replace_sp_char(usermsg)
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    try:
        feedback = Feedback(timestamp=timestamp, username=username, usertel=usertel, userdepartment=userdepartment,
                            usermsg=usermsg)
        conn.add(feedback)
        conn.commit()
        conn.refresh(feedback)
    except:
        pass
    conn.close()
    return timestamp


# 添加人工客服
def add_cs(csid, csname, cspassword):
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    try:
        cs = CS(csid=csid, csname=csname, cspassword=cspassword)
        conn.add(cs)
        conn.commit()
        conn.refresh(cs)
    except:
        pass
    conn.close()
    return csid


# 拉取问题反馈数据
def pull_feedback_data(start_time=None, end_time=None):
    connpool = sessionmaker(bind=engine)
    conn = connpool()  # 获取连接池中一个连接
    data = None
    if start_time is None:
        start_time = 0
    if end_time is None:
        end_time = int(round(time.time() * 1000))
    try:
        data = conn.query(Feedback.index,Feedback.timestamp, Feedback.username, Feedback.usertel, Feedback.userdepartment,
                          Feedback.usermsg
                          ).filter(Feedback.timestamp >= start_time, Feedback.timestamp <= end_time).all()
        return data
    except:
        pass
    conn.close()
    return data


# 拉取问题反馈
def pull_feedback(oneday=None):
    if oneday is None:
        oneday = True
    timestamp_now = int(round(time.time() * 1000))
    if oneday:
        # 近24小时
        time_yesterday=timestamp_now - 86500
        feedback_list = pull_feedback_data(start_time=time_yesterday, end_time=timestamp_now)
    else:
        # 全量
        feedback_list = pull_feedback_data(end_time=timestamp_now)
    keys = ['序列','时间', '姓名', '电话', '单位', '反馈']
    feedbacks = pd.DataFrame(feedback_list, columns=[key for key in keys])
    feedbacks['时间'] = pd.to_datetime(feedbacks['时间'].values, utc=True, unit="ms").tz_convert(
        'Asia/Shanghai').strftime("%Y年%m月%d日 %H:%M:%S")
    # print(feedbacks)
    paperPath = os.path.dirname(os.path.realpath(__file__))
    # excel_writer = pd.ExcelWriter(paperPath + '/feedback/客服反馈' + str(time.strftime('%Y-%m-%d')) + '.xlsx')
    # feedbacks.to_excel(excel_writer=excel_writer,sheet_name='客服反馈',index=False)
    feedbacks.to_excel(paperPath + '/feedback/客服反馈' + str(time.strftime('%Y-%m-%d')) + '.xlsx', sheet_name='客服反馈',
                       index=False)


if __name__ == '__main__':
    # # 测试
    # chat1 = {'1644909798452func_name': 'chat_student', '1644909798452value': "s'd",
    #          '1644909800038func_name': 'chat_csrobot', '1644909800038value': '抱歉，小沪不太明白您的问题呢~',
    #          '1644909802043func_name': 'recommendPanel', '1644909802043value': '', 'userid': 'logout'}
    # # add_csr_local(chat1)
    # print(query_logincs('ma', '1'))
    #
    # print(query_cs('cs01'))
    # data = [{'userid': '服务器', 'message': '您已接通学员，学员ID：！'}]
    # print(data[0]['userid'])
    # print(int(round(time.time() * 1000))-86500)
    usermsg = '啊 吧'
    usermsg_str = []
    for index in range(len(usermsg)):
        s = usermsg[index].replace(' ', '').replace('\n', '').replace('\r', '')
        usermsg_str.append(s)
    usermsg = ''.join(usermsg_str)
    print(usermsg)
