import shgbDB_sqlalchemy as db

if __name__ == '__main__':
    db.pull_feedback(oneday=False)
