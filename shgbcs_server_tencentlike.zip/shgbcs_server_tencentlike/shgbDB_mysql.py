import pymysql

class shgbDB(object):
    def __init__(self):
        self.conn = pymysql.connect(host='localhost', port=3306, user='root', password='123456', database='shgb_csdb',
                                    charset='utf8')
        self.cursor = self.conn.cursor()

    def __del__(self):
        self.cursor.close()
        self.conn.close()

    def execute_sql(self, sql):
        self.cursor.execute(sql)
        for temp in self.cursor.fetchall():
            print(temp)

    def show_chat_history(self):
        find_name = input("请输入学员id")
        sql = "select * from chat_history where userid=%s;"
        self.cursor.execute(sql, [find_name])
        for temp in self.cursor.fetchall():
            print(temp)

    def add_chat_history(self, chat_history, csid):
        userid = chat_history['userid']
        try:
            for chat in chat_history:
                pos_funcname = chat.find('func_name')
                pos_funcvalue = chat.find('value')
                if pos_funcname > -1:
                    timestamp = chat[:pos_funcname]
                    funcname = chat_history[chat]
                    sql = "insert into chat_history(timestamp,funcname,userid,csid) values('%s','%s','%s','%s');" % (
                    timestamp, funcname, userid, csid)
                    self.cursor.execute(sql)
                    self.conn.commit()
                elif pos_funcvalue > -1:
                    timestamp = chat[:pos_funcvalue]
                    funcvalue = chat_history[chat]
                    sql = "update chat_history set funcvalue='%s' where timestamp='%s';" % (funcvalue, timestamp)
                    self.cursor.execute(sql)
                    self.conn.commit()
        except:
            print("聊天记录格式有误")
            print(chat_history)

    def run(self):
        self.show_all_items()

    @staticmethod
    def print_menu():
        print('aaaaaa')
        return 1


def main():
    shgb = shgbDB()
    shgb.run()


if __name__ == '__main__':
    main()
