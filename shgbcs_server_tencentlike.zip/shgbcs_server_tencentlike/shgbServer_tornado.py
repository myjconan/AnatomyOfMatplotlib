# -*- coding: UTF-8 -*-
import urllib
import tornado.web
import tornado.ioloop
import tornado.httpserver
import tornado.options
import os, json, random
import datetime
import time
from tornado.web import RequestHandler, decode_signed_value
from tornado.options import define, options
from tornado.websocket import WebSocketHandler
import shgbDB_sqlalchemy as shgbdb
import threading
import asyncio

# cookie秘钥
secret_key = os.getenv('secret_key')
# websocket跨域域名
cross_origin_domain = '.myjconan.cloud'


# 聊天室
class Chatroom(object):
    def __init__(self, room_id=None, cs=None, user=None, people=None):
        self.id = room_id
        self.cs = cs
        self.user = user
        if people is None:
            self.people = []
        else:
            self.people = people

    def reset(self):
        self.cs = None
        self.user = None
        self.people = []


# 初始化容器
chatroom01 = Chatroom(room_id='01')
chatroom02 = Chatroom(room_id='02')
chatroom03 = Chatroom(room_id='03')
chatroom04 = Chatroom(room_id='04')
chathall = [chatroom01, chatroom02, chatroom03, chatroom04]

user_wait = []  # 用来存放在线用户的容器
cs_wait = []  # 空闲的客服
cs_online = set()  # 在线客服
user_online = set()


# 聊天室控制
def ChatManager():
    asyncio.set_event_loop(asyncio.new_event_loop())
    global user_wait
    global cs_wait
    global chatroom01
    global chatroom02
    global chatroom03
    global chatroom04
    while True:
        try:
            if len(cs_wait) > 0 and len(user_wait) > 0:
                rand = random.randint(0, len(cs_wait) - 1)
                cs_rand = cs_wait[rand]
                chatroom = None
                if cs_rand.csid[len(cs_rand.csid) - 2:] == '01':
                    chatroom = chatroom01
                if cs_rand.csid[len(cs_rand.csid) - 2:] == '02':
                    chatroom = chatroom02
                if cs_rand.csid[len(cs_rand.csid) - 2:] == '03':
                    chatroom = chatroom03
                if cs_rand.csid[len(cs_rand.csid) - 2:] == '04':
                    chatroom = chatroom04
                if chatroom is not None:
                    chatroom.cs = cs_rand
                    chatroom.people.append(cs_rand)
                    chatroom.user = user_wait[0]
                    chatroom.people.append(user_wait[0])
                    del (user_wait[0])
                    del (cs_wait[rand])
                    # 消息提醒
                    for u in chatroom.people:
                        data = None
                        if u == chatroom.cs:
                            data = [{'userid': '服务器',
                                     'message': '您已接通学员，学员ID：%s！' % chatroom.user.userid}]
                            json_message = json.dumps(data)
                            u.write_message(json_message)
                            shgbdb.add_chat_history(funcvalue=data[0]['message'], csid=u.csid,
                                                    userid=chatroom.user.userid)
                            data = [{'userid': '服务器',
                                     'message': '学员历史聊天：%s' % chatroom.user.chat_history}]
                            json_message = json.dumps(data)
                            u.write_message(json_message)
                            shgbdb.add_chat_history(funcvalue=data[0]['message'], csid=u.csid,
                                                    userid=chatroom.user.userid)
                        elif u == chatroom.user:
                            data = [{'userid': '服务器', 'message': '您已接通%s号人工客服！' % chatroom.cs.csid}]
                            json_message = json.dumps(data)
                            u.write_message(json_message)
                            shgbdb.add_chat_history(funcvalue=data[0]['message'],
                                                    csid=chatroom.cs.csid,
                                                    userid=u.userid)
            for chatroom in chathall:
                if chatroom.people is not None:
                    if len(chatroom.people) == 1:
                        # 聊天室只有人工客服
                        if isinstance(chatroom.people[0], ChatforcsHandler):
                            cs_wait.append(chatroom.cs)
                            chatroom.reset()
                        # 聊天室只有学员
                        elif isinstance(chatroom.people[0], ChatHandler):
                            chatroom.user.close()
                            chatroom.reset()
            time.sleep(0.1)
            # for i in chathall:
            #     print(i.id,i.user,i.cs,i.people)
        except:
            print("建立聊天房间失败")


# 主页
class MainHandler(RequestHandler):
    def get(self, *args, **kwargs):
        self.render("shgb.html")

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


class FeedbackHandler(RequestHandler):
    def get(self, *args, **kwargs):
        self.render("feedback.html")

    def post(self, *args, **kwargs):
        try:
            shgbdb.add_feedback(username=self.username, usertel=self.usertel, userdepartment=self.userdepartment,
                                usermsg=self.usermsg)
            self.write("感谢您的反馈，我们会尽快处理并致电回复。")
        except:
            print("feedback写入失败：姓名：%s，电话：%s，单位：%s，反馈：%s" % (
                self.username, self.usertel, self.userdepartment, self.usermsg))
            self.write("感谢您的反馈，我们会尽快处理并致电回复。")

    def prepare(self):
        if self.request.method == 'POST':
            self.username = self.get_argument('username')
            self.usertel = self.get_argument('usertel')
            self.userdepartment = self.get_argument('userdepartment')
            self.usermsg = self.get_argument('js-inputMsg')

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 人工客服登录页
class LoginHandler(RequestHandler):
    def get(self, *args, **kwargs):
        self.render("logincs.html")

    def post(self, *args, **kwargs):
        # sql查询o密码是否匹配
        cs = shgbdb.query_logincs(self.csname, self.cspassword)
        if cs:
            # print("查询到")
            self.csid, self.csname = cs
            self.set_secure_cookie('csname', self.csname, expires_days=1)
            self.set_secure_cookie('csid', str(self.csid), expires_days=1)
            self.redirect('/csrchat/shgbcs')
        else:
            print("logincs没查询到%s" % self.csname)
            self.write("账号或密码错误，请返回重试！")

    def prepare(self):
        if self.request.method == 'POST':
            self.csname = self.get_argument('csname')
            self.cspassword = self.get_argument('cspassword')

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 解决人工客服登录页cookie不生效的重定向
class ShgbcsHandler(RequestHandler):
    def get_current_user(self):
        getcsid = self.get_secure_cookie('csid')
        if getcsid:
            self.csid = getcsid.decode()
            cs = shgbdb.query_cs(self.csid)
            if cs:
                print("ShgbcsHandler授权%s" % self.csid)
                self.csid, self.csname = cs
                if self.csid.find('manager'):
                    pass
                return cs
        else:
            print("ShgbcsHandler未授权")

    @tornado.web.authenticated
    def get(self, *args, **kwargs):
        # self.write("授权的get")
        # print("shgbcs：" + self.get_secure_cookie('csname').decode())
        # print("shgbcs：" + self.get_secure_cookie('csid').decode())
        # a="2|1:0|10:1645082762|4:csid|8:Y3MwMQ==|84c9e4b56b4122712ff73088143eef196d9eebecb91a06928d06d902d60d29d0"
        # a="2|1:0|10:1645082751|4:csid|8:Y3MwMg==|724b68741ce33445088c4bb632c1c259c0a387bfced8739a62438e9b863b3ab4"
        # print(self.get_secure_cookie('csid',a))
        # print(self.require_setting("cookie_secret", "secure cookies"))
        self.write('登陆成功，请点击右下角客服按钮，输入【上工】即可上线！')
        self.render('csinservice.html')

    def write_error(self, stat, **kw):
        if stat == 404:
            self.write('403访问url不存在!')

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 客服聊天框from学员_主页
class CsrChatHandler(RequestHandler):
    def get(self, *args, **kwargs):
        self.render("CustomerService_for_shgb.html")

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 客服聊天框from客服_主页or页面csinservice
class CsChatHandler(RequestHandler):
    def get(self, *args, **kwargs):
        self.render("cschat.html")

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 学员聊天通信
class ChatHandler(WebSocketHandler):

    def open(self):
        print('收到来自%s的学员WebSocket连接' % self.request.remote_ip)
        user_wait.append(self)  # 建立连接后添加用户到容器中
        self.isfreshuser = True
        self.chat_history = ""

    def on_message(self, message):
        try:
            message = json.loads(message)
            if self.isfreshuser:
                els = list(message.items())
                # print(els[len(els)-7:])
                for i in range(len(els) - 1):
                    if els[i][1].find('chat_student'):
                        pass
                    else:
                        # print(els[i + 1][1])
                        self.chat_history += els[i + 1][1] + '，'
                self.userid = message.get('userid')
                shgbdb.add_csr_local(message)
                self.isfreshuser = False
            else:
                if self in user_wait:
                    data = [{'userid': '服务器',
                             'message': '您当前排在第%d位，客服坐席繁忙，请见谅……' % (user_wait.index(self) + 1)}]
                    json_message = json.dumps(data)
                    self.write_message(json_message)
                    shgbdb.add_chat_history(funcvalue=data[0]['message'], userid=self.userid)
                else:
                    for chatroom in chathall:
                        if self in chatroom.people:
                            for u in chatroom.people:
                                if u != self:
                                    data = [{'userid': message.get('userid'),
                                             'message': message.get('message')}]
                                    json_message = json.dumps(data)
                                    u.write_message(json_message)
                                    shgbdb.add_chat_history(funcvalue=data[0]['message'],
                                                            userid=self.userid,
                                                            csid=chatroom.cs.csid,
                                                            funcname="学员to客服")
        except:
            print("学员%s发送信息是失败" % self.userid)

    def on_close(self):
        for chatroom in chathall:
            if self in chatroom.people:
                for u in chatroom.people:
                    if u != self:
                        data = [{'userid': '服务器',
                                 'message': '学员：%s已结束通话，等待学员数：%s' % (self.userid, len(user_wait))}]
                        json_message = json.dumps(data)
                        u.write_message(json_message)
                        shgbdb.add_chat_history(funcvalue=data[0]['message'], csid=u.csid,
                                                userid=self.userid)
                chatroom.people.remove(self)
                break
        if self in user_wait:
            user_wait.remove(self)
        print('断开来自%s的学员WebSocket连接' % self.request.remote_ip)

    def check_origin(self, origin):
        return True
        parsed_origin = urllib.parse.urlparse(origin)
        return parsed_origin.netloc.endswith(cross_origin_domain)

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 人工客服聊天通信
class ChatforcsHandler(WebSocketHandler):
    def open(self):
        # 不信任websocket连接者
        self.iscs = False

    def on_message(self, message):
        try:
            message = json.loads(message)
            # 人工客服关闭学员连接
            if message.get('message') == "cs shut down the conn":
                for chatroom in chathall:
                    if self in chatroom.people:
                        for u in chatroom.people:
                            if u == self:
                                data = [{'userid': '服务器',
                                         'message': '已主动断开学员连接，当前等待学员数：%s' % len(user_wait)}]
                                json_message = json.dumps(data)
                                self.write_message(json_message)
                                shgbdb.add_chat_history(funcvalue=data[0]['message'],
                                                        csid=self.csid,
                                                        userid=chatroom.user.userid)
                                # chatroom.people.remove(u)
                                # cs_wait.append(u)
                            if u != self:
                                data = [{'userid': '服务器', 'message': message.get('message')}]
                                json_message = json.dumps(data)
                                self.write_message(json_message)
                                shgbdb.add_chat_history(funcvalue=data[0]['message'],
                                                        csid=self.csid,
                                                        userid=chatroom.user.userid)
            # 聊天
            if self.iscs:
                # 空闲客服
                if self in cs_wait:
                    data = [{'userid': '服务器',
                             'message': '您目前处于空闲状态，目前在线客服共%d位，空闲客服共%d位，等待学员数：%s，在线学员数：%s' % (
                                 len(cs_online), len(cs_wait), len(user_wait), len(user_online))}]
                    json_message = json.dumps(data)
                    self.write_message(json_message)
                # 非空闲
                else:
                    for chatroom in chathall:
                        if self in chatroom.people:
                            try:
                                for u in chatroom.people:  # 向在线用户广播消息
                                    if u != self:
                                        data = [{'userid': self.csid,
                                                 'message': message.get('message')}]
                                        json_message = json.dumps(data)
                                        u.write_message(json_message)
                                        shgbdb.add_chat_history(funcvalue=data[0]['message'],
                                                                userid=u.userid,
                                                                csid=self.csid, funcname="客服to学员")
                            except:
                                print("人工客服%s传递消息出错" % self.csid)

            else:
                # 检查cs用户
                csid_secure_cookie = message.get('csid')
                csid_cookie = decode_signed_value(
                    secret_key,
                    'csid',
                    csid_secure_cookie[1:len(csid_secure_cookie) - 1]
                )
                self.csid = csid_cookie.decode()
                cs = shgbdb.query_cs(self.csid)
                if cs:
                    self.iscs = True
                    self.csid, self.csname = cs
                cs_wait.append(self)  # 建立连接后添加用户到容器中
                cs_online.add(self)
                time.sleep(1)
                data = [{'userid': '服务器',
                         'message': '客服%s已上工，目前在线客服共%d位，空闲客服共%d位，等待学员数：%s' % (
                             self.csname, len(cs_online), len(cs_wait), len(user_wait))}]
                json_message = json.dumps(data)
                self.write_message(json_message)
                shgbdb.add_chat_history(funcvalue=data[0]['message'], csid=self.csid)
        except:
            print("客服%s发送消息失败" % self.csid)

    def on_close(self):
        if self in cs_wait:
            cs_wait.remove(self)  # 用户关闭连接后从容器中移除用户
        for chatroom in chathall:
            if self in chatroom.people:
                for u in chatroom.people:
                    if u != self:
                        u.close()
                chatroom.reset()
        cs_online.remove(self)
        print("关闭%s的websocket连接" % self.csid)

    def check_origin(self, origin):
        return True
        parsed_origin = urllib.parse.urlparse(origin)
        return parsed_origin.netloc.endswith(cross_origin_domain)

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


# 上传学员端本地数据
# class Csr_localHandler(WebSocketHandler):
#     def open(self):
#         print('收到来自%s的Csr_localHandler连接' % self.request.remote_ip)
#
#     def on_message(self, message):
#         print('将来自%s的Csr_localHandler的数据入库' % self.request.remote_ip)
#         try:
#             message = json.loads(message)
#             # print(type(message), message)
#             shgbdb.add_csr_local(message)
#             data = [{'userid': '服务器', 'message': 'cs shut down the conn'}]
#             json_message = json.dumps(data)
#             self.write_message(json_message)
#             self.close()
#         except:
#             print('来自%s的csr_local关闭出错' % self.request.remote_ip)
#
#     def on_close(self):
#         print('断开来自%s的Csr_localHandler连接' % self.request.remote_ip)
#
#     def check_origin(self, origin):
#         return True
#         parsed_origin = urllib.parse.urlparse(origin)
#         return parsed_origin.netloc.endswith(cross_origin_domain)
#
#     def set_default_headers(self):
#         self.set_header('Server', 'ShgbCS1.0')


class Csr_localHandler(RequestHandler):
    def post(self):
        print('将来自%s的Csr_localHandler的数据入库' % self.request.remote_ip)
        try:
            self.chat_history = self.get_argument('chat_history')
            message = json.loads(self.chat_history)
            # print(message)
            # print(message.get('userid'))
            shgbdb.add_csr_local(message)
        except:
            print('来自%s的csr_local关闭出错' % self.request.remote_ip)

    def set_default_headers(self):
        self.set_header('Server', 'ShgbCS1.0')


if __name__ == '__main__':
    tornado.options.parse_command_line()  # 允许命令行启动程序

    app = tornado.web.Application([  # 定义处理web请求的应用程序
        (r"/", MainHandler),  # shgb主页
        (r"/csrchat/logincs", LoginHandler),  # 客服登录
        (r"/csrchat/shgbcs", ShgbcsHandler),  # 重定向客服页面
        (r"/csrchat/chat", ChatHandler),  # 学员请求人工客服fromshgb外链
        (r"/csrchat/chatforcs", ChatforcsHandler),  # 客服请求人工客服fromshgb外链
        (r"/csrchat/tocsr_local", Csr_localHandler),  # 本地机器人数据上传
        (r"/csrchat/cschat", CsChatHandler),  # 客服聊天框from客服_主页
        (r"/csrchat", CsrChatHandler),  # 客服聊天框from学员_主页
        (r"/csrchat/feedback", FeedbackHandler),  # 问题反馈
        # (r"/csrchat/csdata", DataPanelHandler), #数据面板
    ], websocket_ping_interval=5,  # WebSocket ping探活包发送间隔秒数
        login_url='/csrchat/logincs',  # 如果用户没有登录, 用户将会被重定向到这个页面
        static_path=os.path.join(os.path.dirname(__file__), "csrchat", "static"),  # 配置应用程序前端所需静态文件目录
        static_url_prefix="/csrchat/static/",
        template_path=os.path.join(os.path.dirname(__file__), "csrchat", "html"),  # 配置html文件路径
        xsrf_cookies=True,  # ,防止跨站请求攻击，在post请求中起效,
        cookie_secret=secret_key,
        # 安全cookie用预置秘钥 base64.b64encode(uuid.uuid4().bytes + uuid.uuid4().bytes)
        # debug=True  # 配置调试级别
    )

    threads = [threading.Thread(target=ChatManager),
               ]
    for t in threads:
        t.start()

    http_server = tornado.httpserver.HTTPServer(app)  # 将应用处理逻辑 传递给HTTPServer 服务
    define("port", default=80, type=int)  # 设置一个监听地址
    http_server.listen(options.port)  # 配置监听地址到 HTTPServe
    print('已启动服务器')
    tornado.ioloop.IOLoop.current().start()  # 启动应用

# tornado源码修改：
# 1.添加了web中StaticFileHandler中set_headers中self.set_header('Server', 'ShgbCS1.0')
# 2.修改了web中RequestHandler的clear中"Server": "TornadoServer/%s" % tornado.version,->"Server": "ShgbCS1.0",
